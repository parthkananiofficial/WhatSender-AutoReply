# Privacy Policy - Watomatic Android App

The app does not automatically collect any personally identifiable data without the explicit consent of the user.

As of this version, no data is collected directly from the app. This privacy policy will be updated if it changes in the future and the developer will take necessary steps to comply with Google Play store or other other app store policies.

Watomatic is an open source. You can find the code at the following link: https://github.com/adeekshith/watomatic

