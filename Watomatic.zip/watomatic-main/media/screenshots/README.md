[❰ Back to home](../../README.md)

# Screenshots | Watomatic

| main          | editor        | demo on whatsapp  |
| ------------- |:-------------:| :----------------:|
| ![main screen](./pixel3a-watomatic-main.png) | ![editor screen](./pixel3a-watomatic-editor.png) | ![on whatsapp](./pixel3a-whatsapp-scr.png) |

[❰ Back to home](../../README.md)

